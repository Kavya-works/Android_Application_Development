package com.example.lostitemapp.models
import androidx.room.Entity
import androidx.room.PrimaryKey

// TODO: Define your database table here
@Entity(tableName = "lost_items")
data class LostItem(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val itemName: String,
    val foundBy: String,
    val phone: String,
    val address: String,
    val latitude: Double,
    val longitude: Double,
    val image: String
)