package com.example.lostitemapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.room.Room
import com.example.lostitemapp.adapters.LostItemAdapter
import com.example.lostitemapp.databinding.ActivityMainBinding
import com.example.lostitemapp.db.LostItemDao
import com.example.lostitemapp.db.MyDatabase
import com.example.lostitemapp.models.LostItem
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import kotlinx.coroutines.launch
class MainActivity : AppCompatActivity(), OnMapReadyCallback {
    // recycler view adapter and list of items to show
    lateinit var listAdapter: LostItemAdapter

    var lostItemsList:MutableList<LostItem> = mutableListOf(
    )

    // map
    lateinit var mMap: GoogleMap

    // TODO: Uncomment this database code
    lateinit var db: MyDatabase
    lateinit var lostItemDao: LostItemDao


    // TODO: Replace this with view bindings
    private lateinit var binding: ActivityMainBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        enableEdgeToEdge()
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        // toolbar
        supportActionBar!!.title = "All Lost Items"

        // get map ui element
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.fragment_map) as SupportMapFragment
        mapFragment.getMapAsync(this)


        // setup the adapter
        listAdapter = LostItemAdapter(this, lostItemsList, onButtonPressed = {position:Int -> buttonPressed(position)}, onRowPressed = { position:Int -> rowClicked(position)})

        // setup the listview
        // TODO: Replace this with view bindings
        binding.lv.adapter = listAdapter
        // TODO: Initialize the db
         db =  Room.databaseBuilder(applicationContext, MyDatabase::class.java, "lost-items-db").build()
         lostItemDao = db.lostItemDao()
    }

    private fun loadLostItems() {
        lifecycleScope.launch {
            lostItemsList.clear()
            val itemsFromDB = lostItemDao.getAllLostItems()
            lostItemsList.addAll(itemsFromDB)
            listAdapter.notifyDataSetChanged()
        }
    }

    // ------- google map -----------------------------
    override fun onMapReady(googleMap: GoogleMap) {
        this.mMap = googleMap
    }

    // ------- click handlers for the listview -------
    fun rowClicked(position:Int) {
        val selectedItem = lostItemsList[position]
        mMap.clear()

        val location = LatLng(selectedItem.latitude, selectedItem.longitude)
        mMap.addMarker(
            MarkerOptions()
                .position(location)
                .title(selectedItem.address)
        )
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 15f))
        Toast.makeText(this, "You clicked on the row", Toast.LENGTH_SHORT).show()
    }

    fun buttonPressed(position:Int) {
        val selectedItem:LostItem = lostItemsList.get(position)
        Toast.makeText(this, "You clicked on the button", Toast.LENGTH_SHORT).show()
        // TODO: Code that should execute when button pressed
        val intent: Intent = Intent(Intent.ACTION_VIEW)
        intent.data = Uri.parse("sms:${selectedItem.phone}")
        intent.putExtra("sms_body", "Hi ${selectedItem.foundBy}, you found my ${selectedItem.itemName}, thanks! Can we meet up?")

        if (intent.resolveActivity(packageManager) != null) {
            startActivity(intent)
        } else {
            Toast.makeText(this, "No SMS app found", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        loadLostItems()
    }

    // ------- toolbar menu items ---------------------
    // reference: https://developer.android.com/develop/ui/views/components/menus#options-menu
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.options_menu, menu)
        return true
    }
    // reference: https://developer.android.com/develop/ui/views/components/menus#RespondingOptionsMenu
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle item selection.
        return when (item.itemId) {
            R.id.mi_report_item -> {
                val intent = Intent(this@MainActivity, ReportLostItemActivity::class.java)
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}