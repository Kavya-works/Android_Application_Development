package com.example.lostitemapp.db
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.lostitemapp.models.LostItem

// TODO: Uncomment this code when you are ready to work with your database
// TODO: Remember to follow the practice described in class
// TODO: If you If you encounter errors like: "Room cannot verify the data integrity.
// TODO: Looks like you've changed schema but forgot to update the version number.", this can be solved by:
// TODO: a. uninstall the app, then reinstall the app
// TODO: b. OR, incrementing the version number below (version = 2, version = 3, etc)

@Database(entities = [LostItem::class], version = 1)
abstract class MyDatabase : RoomDatabase() {
    abstract fun lostItemDao(): LostItemDao
}