package com.example.lostitemapp.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.lostitemapp.models.LostItem

@Dao
interface LostItemDao {
    @Query("SELECT * FROM lost_items")
    suspend fun getAllLostItems(): List<LostItem>

    @Insert
    suspend fun insertLostItem(lostItem: LostItem)
}