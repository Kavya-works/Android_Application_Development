package com.example.lostitemapp

import android.location.Address
import android.location.Geocoder
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.room.Room
import com.example.lostitemapp.databinding.ActivityReportLostItemBinding
import com.example.lostitemapp.db.LostItemDao
import com.example.lostitemapp.db.MyDatabase
import com.example.lostitemapp.models.LostItem
import kotlinx.coroutines.launch
import java.util.Locale

// TODO: Implement the code for this screen. The UI is already built for you.
// TODO: Remember to use view bindings!
class ReportLostItemActivity : AppCompatActivity() {
    private lateinit var binding: ActivityReportLostItemBinding
    private lateinit var db: MyDatabase
    private lateinit var lostItemDao: LostItemDao
    private lateinit var geocoder: Geocoder
    private var selectedImageUri: Uri? = null

    // Photo picker launcher
    private val pickMedia = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            selectedImageUri = uri
            binding.ivSelectedPhoto.setImageURI(uri)
            binding.ivSelectedPhoto.visibility = View.VISIBLE
            Log.d("PhotoPicker", "Selected URI: $uri")
        } else {
            Log.d("PhotoPicker", "No media selected")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReportLostItemBinding.inflate(layoutInflater)
        setContentView(binding.root)
        enableEdgeToEdge()
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        // adds a toolbar with a title and back button
        supportActionBar!!.title = "Report Lost Item"
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)

        db = Room.databaseBuilder(applicationContext, MyDatabase::class.java, "lost-items-db").build()
        lostItemDao = db.lostItemDao()

        geocoder = Geocoder(this, Locale.getDefault())

        binding.btnSelectPhoto.setOnClickListener {
            pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }

        binding.btnSubmit.setOnClickListener {
            submitForm()
        }
    }

    private fun submitForm() {
        val itemName = binding.etItemName.text.toString().trim()
        val foundBy = binding.etFoundBy.text.toString().trim()
        val phone = binding.etPhone.text.toString().trim()
        val address = binding.etAddress.text.toString().trim()

        // Validation
        if (itemName.isEmpty() || foundBy.isEmpty() || phone.isEmpty() || address.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        if (selectedImageUri == null) {
            Toast.makeText(this, "Please select a photo", Toast.LENGTH_SHORT).show()
            return
        }

        // Geocode the address
        lifecycleScope.launch {
            try {
                val addresses: List<Address>? = geocoder.getFromLocationName(address, 1)

                if (addresses.isNullOrEmpty()) {
                    Toast.makeText(this@ReportLostItemActivity, "Address not found", Toast.LENGTH_SHORT).show()
                    return@launch
                }

                val location = addresses[0]
                val latitude = location.latitude
                val longitude = location.longitude

                // Create LostItem object
                val lostItem = LostItem(
                    itemName = itemName,
                    foundBy = foundBy,
                    phone = phone,
                    address = address,
                    latitude = latitude,
                    longitude = longitude,
                    image = selectedImageUri.toString()
                )

                // Save to database
                lostItemDao.insertLostItem(lostItem)

                // Clear form
                clearForm()

                Toast.makeText(this@ReportLostItemActivity, "Item reported successfully!", Toast.LENGTH_SHORT).show()

            } catch (e: Exception) {
                Toast.makeText(this@ReportLostItemActivity, "Geocoding error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                Log.e("ReportActivity", "Geocoding failed", e)
            }
        }
    }

    private fun clearForm() {
        binding.etItemName.text.clear()
        binding.etFoundBy.text.clear()
        binding.etPhone.text.clear()
        binding.etAddress.text.clear()
        binding.ivSelectedPhoto.setImageURI(null)
        binding.ivSelectedPhoto.visibility = View.GONE
        selectedImageUri = null
    }

    // -------- handle clicks on the toolbar -----------
    // reference: https://developer.android.com/develop/ui/views/components/menus#RespondingOptionsMenu
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            // detects when the back button is pressed
            android.R.id.home -> {
                // return to previous screen
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}