package com.example.lostitemapp.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import com.example.lostitemapp.databinding.RowLayoutBinding
import com.example.lostitemapp.models.LostItem


// TODO: You may modify this constructor as needed.
class LostItemAdapter(
    context: Context,
    lostItems: List<LostItem>,
    var onButtonPressed:(positionClicked:Int)->Unit,
    var onRowPressed:(positionClicked:Int)->Unit) :
    ArrayAdapter<LostItem>(context, 0, lostItems) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        // This is how you create a binding variable to access elements in the row_layout.xml file
        val binding: RowLayoutBinding = RowLayoutBinding.inflate(LayoutInflater.from(context), parent, false)
        val view = convertView ?: binding.root

        val lostItem = getItem(position)

        // TODO: Modify this code as needed to populate the UI with elements in the res/row_layout.xml file
        binding.tvItemName.text = lostItem?.itemName
        binding.tvFoundBy.text = "Found by: ${lostItem?.foundBy}"

        // this is example of detecting a row click
        binding.root.setOnClickListener {
            onRowPressed(position)
        }
        binding.btnContact.setOnClickListener {
            onButtonPressed(position)
        }

        return view
    }
}
